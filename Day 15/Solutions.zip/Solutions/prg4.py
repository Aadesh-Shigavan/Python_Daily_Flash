a = 7

for i in range(1,5):
	for j in range(i):
		a -=1
		print(a+i,end=" ")

	print()