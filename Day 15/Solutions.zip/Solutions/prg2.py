a = int(input("Mass= "))

b = int(input("Velocity="))

kin = 1/2*a*b*b

print("kinetic Energy of that object:",kin)